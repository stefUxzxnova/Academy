package com.staffmanagement.system.managers;

import java.util.Scanner;

public interface Manager {
    void executeCommand(int command, Scanner scanner);
}
